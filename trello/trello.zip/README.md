Trello2HTML
===

You can view detailed Trello Boards and export them to HTML (Save Page doesn't
work). An ideal use for this is to generate weekly/monthly reports (at least that
is how our team uses it.) Another use of this app is to directly append a board
id to the hash, for example, the report for the official Trello Development is
http://tianshuo.github.com/trello/#4d5ea62fd76aa1136000000c

The hosted version is on http://tianshuo.github.com/trello/ At the present moment,
only Chrome is supported. (I haven't tested firefox yet)

There is also a blog article on this: 
http://tianshuohu.diandian.com/post/2012-06-08/Trello-Export-as-html

